package com.springbootjpa.postrgresql.repository;

import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import com.springbootjpa.postrgresql.model.Author;

public interface AuthorRepository extends JpaRepository<Author, Long> {
	
	List<Author> findByName(String Name);
	List<Author> findAuthorsByBooksId(Long bookId);

}

package com.springbootjpa.postrgresql.model;



import java.util.Date;
import java.util.Set;
import java.util.HashSet;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.JoinTable;
import jakarta.persistence.ManyToMany;
import jakarta.persistence.Table;


@Entity
@Table (name="book")
public class Book{
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY, generator="book_generator")
 private long id;
	
 @Column(name="name")
 private String name;
 
 @Column(name = "publish-date")
 private Date publishdate;
 
 @Column(name ="stock")
 private long stock;
 
 @Column (name = "price")
 private double price;
 
 @ManyToMany(fetch=FetchType.LAZY, cascade = {CascadeType.PERSIST,CascadeType.MERGE})
 @JoinTable(name="book_author",
 joinColumns= {@JoinColumn(name ="book_id")},inverseJoinColumns= {@JoinColumn(name="author_id")})
 private Set<Author> authors =new HashSet<>();
 
 @ManyToMany(fetch=FetchType.LAZY, cascade= {CascadeType.PERSIST,CascadeType.MERGE})
 @JoinTable(name="book_publisher",
 joinColumns= {@JoinColumn(name="book_id")},inverseJoinColumns= {@JoinColumn(name="publisher_id")})
 private Set<Publisher> publishers= new HashSet<>();
 
 public Book() {
	 
 }
 public Book(String name,Date publish_date,double price, long stock) {
	 this.name=name;
	 this.publishdate=publish_date; 
	 this.price=price;
	 this.stock=stock;
 }

 public long getId() {
	return id;
}
public void setId(long id) {
	this.id = id;
}
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public Date getPublishdate() {
	return publishdate;
}
public void setPublishdate(Date publishdate) {
	this.publishdate = publishdate;
}
public Set<Author> getAuthors() {
	return authors;
}
public void setAuthors(Set<Author> authors) {
	this.authors = authors;
}

public Set<Publisher> getPublishers() {
	return publishers;
}
public void setPublishers(Set<Publisher> publishers) {
	this.publishers = publishers;
}
public void addAuthor(Author author)
{
	this.authors.add(author);
	author.getBooks().add(this);
}


public long getStock() {
	return stock;
}
public void setStock(long stock) {
	this.stock = stock;
}
public double getPrice() {
	return price;
}
public void setPrice(double price) {
	this.price = price;
}

public void removeAuthor(long authorId)
{
	Author author=this.authors.stream().filter(a->a.getId()==authorId).findFirst().orElse(null);
	if(author!=null) {
		this.authors.remove(author);
		author.getBooks().remove(this);
	}
}

public void addPublisher(Publisher publisher)
{
	this.publishers.add(publisher);
	publisher.getBooks().add(this);
}

public void removePublisher(long publisherId)
{
	Publisher publisher=this.publishers.stream().filter(p->p.getId()==publisherId).findFirst().orElse(null);
	if(publisher!=null) {
		this.publishers.remove(publisher);
		publisher.getBooks().remove(this);
	}
}
@Override
 public String toString() {
	 return "Book [id=" + id + ", name=" + name + ", publishdate =" + publishdate +"]";
 } 
}

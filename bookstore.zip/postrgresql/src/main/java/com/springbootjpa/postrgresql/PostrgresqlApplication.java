package com.springbootjpa.postrgresql;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;


@SpringBootApplication
public class PostrgresqlApplication {

	public static void main(String[] args) {
		SpringApplication.run(PostrgresqlApplication.class, args);
	}

}

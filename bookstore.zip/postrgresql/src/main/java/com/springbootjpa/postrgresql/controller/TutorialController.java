package com.springbootjpa.postrgresql.controller;

import java.util.ArrayList;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;


import com.springbootjpa.postrgresql.model.Tutorial;
import com.springbootjpa.postrgresql.repository.TutorialRepository;
import com.springbootjpa.postrgresql.repository.BookRepository;
import com.springbootjpa.postrgresql.exception.ResourceNotFoundException;

@CrossOrigin(origins = "http://localhost:8081")
@RestController
@RequestMapping("/api")
public class TutorialController {

	@Autowired
	TutorialRepository tutorialRepository;
	
	@Autowired
	BookRepository bookRepository;
	
	// Display all title details in tutorial table
	@GetMapping("/book/tutorials")
	public ResponseEntity<List<Tutorial>> getAllTutorials(@RequestParam(required = false) String title) {
		try {
			List<Tutorial> tutorials = new ArrayList<Tutorial>();

			if (title == null)
				tutorialRepository.findAll().forEach(tutorials::add);
			else
				tutorialRepository.findByTitleContaining(title).forEach(tutorials::add);

			if (tutorials.isEmpty()) {
				return new ResponseEntity<>(HttpStatus.NO_CONTENT);
			}

			return new ResponseEntity<>(tutorials, HttpStatus.OK);
		} catch (Exception e) {
			return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	// Display Title details against book ID
	@GetMapping("/book/{bookid}/tutorials")
	public ResponseEntity<List<Tutorial>> getAllTutorialByBookId(@PathVariable("bookid") long bookid){

		if (bookRepository.findById(bookid).isPresent()) {
			List <Tutorial> tutorial=tutorialRepository.findByBookId(bookid);
			return new ResponseEntity<>(tutorial, HttpStatus.OK);
		} 
			return new ResponseEntity<>(HttpStatus.NOT_FOUND);
		}
	
	// Display Book against title ID
	@GetMapping("/book/tutorials/{tutorialid}")
	public ResponseEntity<Tutorial> getTutorialById(@PathVariable("tutorialid") long id) {
		Optional <Tutorial> tutorialdata=tutorialRepository.findById(id);

		if (tutorialdata.isPresent()) {
			Tutorial _tutorial=tutorialdata.get();
			return new ResponseEntity<>(_tutorial, HttpStatus.OK);
		} 
			return new ResponseEntity<>(HttpStatus.NOT_FOUND);
		}
	
	// Create title details in the tutorial table against book id
	@PostMapping({"/book/{bookid}/tutorials","/book/tutorials/{bookid}"})
	public ResponseEntity<Tutorial>createTutorial(@PathVariable ("bookid") Long bookid,
			@RequestBody Tutorial tutorialRequest){
		Tutorial tutorial = bookRepository.findById(bookid).map(book -> { tutorialRequest.setBook(book);
		return tutorialRepository.save(tutorialRequest);
		}).orElseThrow(() -> new ResourceNotFoundException ("not found" + bookid));
		
		return new ResponseEntity<>(tutorial,HttpStatus.OK);
		
	}
	
	/*@PostMapping("/tutorials")
	  public ResponseEntity<Tutorial> createTutorial(@RequestBody Tutorial tutorial) {
	    Tutorial _tutorial = tutorialRepository.save(new Tutorial(tutorial.getTitle(), tutorial.getDescription(), true));
	    return new ResponseEntity<>(_tutorial, HttpStatus.CREATED);
	  }*/
	
	// Edit title details for specific title id
	@PutMapping("/book/tutorials/{id}")
	public ResponseEntity<Tutorial> updateTutorial(@PathVariable("id") long id, @RequestBody Tutorial tutorial) {
		Tutorial tutorialData = tutorialRepository.findById(id)
				.orElseThrow(() -> new ResourceNotFoundException ("not found tutorialid "+ id + "not"));
		tutorialData.setTitle(tutorial.getTitle());
		tutorialData.setDescription(tutorial.getDescription());
		tutorialData.setPublished(tutorial.isPublished());
	
			return new ResponseEntity<>(tutorialRepository.save(tutorialData), HttpStatus.OK);
}

	// Delete specific title details in tutorial table
	@DeleteMapping("/book/tutorials/{id}")
	public ResponseEntity<HttpStatus> deleteTutorial(@PathVariable("id") long id) {
		try {
			tutorialRepository.deleteById(id);
			return new ResponseEntity<>(HttpStatus.NO_CONTENT);
		} catch (Exception e) {
			return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	// Delete all title details against the book id in tutorial table
	@DeleteMapping("/book/{bookid}/tutorials")
	public ResponseEntity<List<Tutorial>> deleteAllTutorialsofBook(@PathVariable (value="bookid") Long bookId) {
			if (!bookRepository.existsById(bookId)) {
			throw new ResourceNotFoundException("not found id "+ bookId);
			}
			bookRepository.deleteById(bookId);
			
			return new ResponseEntity<>(HttpStatus.NO_CONTENT);

	}

	// Display all title if published details is true
	@GetMapping("/book/tutorials/published")
	public ResponseEntity<List<Tutorial>> findByPublished() {
		try {
			List<Tutorial> tutorials = tutorialRepository.findByPublished(true);

			if (tutorials.isEmpty()) {
				return new ResponseEntity<>(HttpStatus.NO_CONTENT);
			}
			return new ResponseEntity<>(tutorials, HttpStatus.OK);
		} catch (Exception e) {
			return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
}

package com.springbootjpa.postrgresql.repository;

import java.util.Date;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;


import com.springbootjpa.postrgresql.model.Book;


public interface BookRepository extends JpaRepository<Book, Long> {
  List<Book> findByName(String Name);
  List<Book> findByPublishdate(Date Publishdate);
  List<Book> findBooksByAuthorsId(Long authorId);
 
}